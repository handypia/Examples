var express = require('express');
var router = express.Router();

var dateFormat = require('dateformat');
var Gpio = require('onoff').Gpio;
var handypia = require('../lib/handypia_platform');
var utils = require('../utils/utils');

/**
 * oneM2M actuator LED on/off example
 * DESCRIPTIONS This LED module used to test module that it is DFR0021-R Digital Red LED Light module in DFROBOT
 * METHOD POST
 * BODY Content-Type application/json
 */
router.post('/:' + global.config.sensorTag.AE.origin, function(req, res, next) {
	var query = utils.getRequestQuery(req, res);
	var ipsoObjectName = handypia.getIpsoSmartObjectName(query.targets);

	if(!handypia.isConnectedDevice()) {
		handypia.sendReport(ipsoObjectName, {
			thingId : global.config.sensorTag.AE.origin,
			time : dateFormat(new Date(), 'yyyymmddHHMMss'),
			resourceId : ipsoObjectName,
			value : {
				result : 'failed',
				message : 'device is not connected'
			}
		}, 'device is not connected');

		res.json({
			code : 404,
			message : 'Device is not connected'
		});
		return;
	}

	if(ipsoObjectName){
		var val = 0;
		switch (query.state.switch) {
			case 'on':
				val = 1;
				break;
			default:
				val = 0;
				break;
		}

		// The GPIO construction number is BCM standard number
		// If number 17 in BCM it is 0 in wPi.
		// Open terminal and type in this command ' gpio readall '
		var led = new Gpio(17, 'out');
		
		led.write(val, function(err){
			if(err){
				console.error('> ERROR: ', err);

				handypia.sendReport(ipsoObjectName, {
					thingId : global.config.sensorTag.AE.origin,
					time : dateFormat(new Date(), 'yyyymmddHHMMss'),
					resourceId : ipsoObjectName,
					value : {
						result : 'error',
						message : err.message
					}
				}, 'error');
				
				res.json({
					code : 500,
					message : err
				});
				return;
			}

			switch (val) {
				case 0:
					console.log('> LED OFF');
					break;
			
				case 1:
					console.log('> LED ON');
					break;
			}

			handypia.sendReport(ipsoObjectName, {
				thingId : global.config.sensorTag.AE.origin,
				time : dateFormat(new Date(), 'yyyymmddHHMMss'),
				resourceId : ipsoObjectName,
				value : {
					result : 'success'
				}
			}, 'success');

			res.json({
				code : 200,
				message : 'success'
			});
		});
	} else {
		handypia.sendReport(ipsoObjectName, {
			thingId : global.config.sensorTag.AE.origin,
			time : dateFormat(new Date(), 'yyyymmddHHMMss'),
			resourceId : ipsoObjectName,
			value : {
				result : 'error',
				message : 'No such resources'
			}
		}, 'No such resources');

		res.json({
			code : 404,
			message : 'No such resources'
		});
	}
});

module.exports = router;