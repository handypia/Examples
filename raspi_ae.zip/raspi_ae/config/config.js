var config = {};

config.debug = false;

config.scl = {
	base : {
		url : 'http://onem2m.iotmeca.com:8080/~/handypia-in/base',
		origin : 'handypia-in'
		//url : 'http://10.30.5.184:18080/~/handypia-in/base',
		//origin : 'handypia-in'
	}
}

config.sensorTag = {
	AE : {
		labels : 'name:TI, SensorTag manufacturer:TI model:NA domain:signage category:indor-weather-station resources:temperature resource:humidity type:sensor poi:HANDYSOFT/5F/MeettingRoom address:49,Daewangpangyo-ro,644Beon-gil,Bundang-gu,Seongnam-si,Gyeonggi-do owners:HANDYSOFT users:solgen@handysoft.co.kr keywords:Handypia keywords:signage',
		prefix : 'S_',
		// origin is name of device's id that it is set to device management in the handypia platform service, value use to sensorTag.id when if default value is null, 
		origin : 'S0.2.481.2.100.0.73.74_AE',
		suffix : '_AE',
		poa : 'http://10.30.5.63:8080/actuator'
	},
	containers : {
		default : ['DESCRIPTOR', 'STATUS'],
		cc2540 : ['magnetometer', 'barometric', 'accelerometer', 'gyroscope'],
		cc2650 : ['temperature', 'humidity', 'object_temperature', 'ambient_temperature', 'magnetometer', 'barometric', 'accelerometer', 'gyroscope', 'luxometer'],
		actuator : ['switch']
	},
	crontab : {
		connectRetry : '*/5 * * * * *',
		sensingReport : '*/10 * * * * *'
	}
}

module.exports = config;
