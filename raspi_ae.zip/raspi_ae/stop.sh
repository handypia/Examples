#!/bin/bash

forever stopall
