/* -----------------------------------------------
 Global configuration
----------------------------------------------- */
var config = global.config;
/* -------------------------------------------- */

var async = require('async');
var crontab = require('node-crontab');
var dateFormat = require('dateformat');
var device = require('sensortag');

var handypia = require('../lib/handypia_platform');
var request = require('request');
var sleep = require('sleep');

var isConnecting = false;
var isReporting = false;
var isDeviceRegistered = true;
var connectedSensorTag = null;

function enableSensors(cb, sensorTag) {
	var sensors = eval('global.config.sensorTag.containers.' + sensorTag.type);
	console.log('-------------------------------------------------------------------');
	async.each(sensors, function(sensor, ecb){
		switch (sensor) {
			case 'temperature':
				sensorTag.enableIrTemperature(function(err) {
					if (err) {
						console.error(err);
						ecb();
						return;
					}

					handypia.addEnabledSensor('object_temperature');
					handypia.addEnabledSensor('ambient_temperature');
					ecb();
				});
				break;
			case 'accelerometer':
				sensorTag.enableAccelerometer(function(err) {
					if (err) {
						console.error(err);
						ecb();
						return;
					}

					handypia.addEnabledSensor(sensor);
					ecb();
				});
				break;
			case 'humidity':
				sensorTag.enableHumidity(function(err) {
					if (err) {
						console.error(err);
						ecb();
						return;
					}

					handypia.addEnabledSensor('temperature');
					handypia.addEnabledSensor('humidity');
					ecb();
				});
				break;
			case 'magnetometer':
				sensorTag.enableMagnetometer(function(err) {
					if (err) {
						console.error(err);
						ecb();
						return;
					}

					handypia.addEnabledSensor(sensor);
					ecb();
				});
				break;
			case 'barometric':
				sensorTag.enableBarometricPressure(function(err) {
					if (err) {
						console.error(err);
						ecb();
						return;
					}

					handypia.addEnabledSensor(sensor);
					ecb();
				});
				break;
			case 'gyroscope':
				sensorTag.enableGyroscope(function(err) {
					if (err) {
						console.error(err);
						ecb();
						return;
					}

					handypia.addEnabledSensor(sensor);
					ecb();
				});
				break;
			case 'luxometer':
				sensorTag.enableLuxometer(function(err) {
					if (err) {
						console.error(err);
						ecb();
						return;
					}

					handypia.addEnabledSensor(sensor);
					ecb();
				});
				break;
			default:
				ecb();
				break;
		}
	}, function (err) {
		if(err){
			cb(err);
			return;
		}

		console.log('enabled sensor(s) in sensorTag ------------------------------------');
		console.log(handypia.getEnableSensors());
		console.log('-------------------------------------------------------------------');
		cb();
	})
}

function getConnnectDevice() {
	if (!isConnecting && !connectedSensorTag) {
		isConnecting = true;
		console.log('connectting .......');
		device.discover(function (sensorTag) {
			sensorTag.connectAndSetup(function(err) {
				if (err) {
					console.log('ERROR ==>> ', err);
					sensorTag.disconnect();
					return;
				}

				sensorTag.on('disconnect', function() {
					console.log('disconnected');
					handypia.removeAllSensor();
					isReporting = false;
					isConnecting = false;
					connectedSensorTag = null;
					handypia.setConnectedDevice(false);
					device.stopDiscoverAll(function() {
						sleep.sleep(5);
					});
				});

				console.log('connectted device');

				async.waterfall([
					function(cb) {
						enableSensors(cb, sensorTag);
					}, function(cb) {
						handypia.registration(cb, sensorTag);
					}
				], function(err) {
					if (err) {
						console.error(err);
						sensorTag.disconnect();
						return;
					}

					connectedSensorTag = sensorTag;
					handypia.setConnectedDevice(true);
					sleep.sleep(5);
				});
			});
		});
	}
}

function sensingReport() {
	if (!connectedSensorTag) {
		return;
	}

	if (!isDeviceRegistered) {
		return;
	}

	if (isReporting) {
		return;
	}

	console.log('-------------------------------------------------------------------');

	isReporting = true;

	async.waterfall([
		function(cb) {
			if(!handypia.hasContainSensor('temperature')) {
				cb();
				return;
			}

			connectedSensorTag.readIrTemperature(function(err, objTemp, ambientTemp) {
				if (err) {
					console.log('> Read IR temperature error: ', err);
					cb();
					return;
				}

				handypia.sendReport('object_temperature', {
					thingId : config.sensorTag.AE.origin,
					time : dateFormat(new Date(), 'yyyymmddHHMMss'),
					resourceId : 'object_temperature',
					value : {
						object_temperature : objTemp.toFixed(1)
					}
				}, objTemp.toFixed(1));

				handypia.sendReport('ambient_temperature', {
					thingId : config.sensorTag.AE.origin,
					time : dateFormat(new Date(), 'yyyymmddHHMMss'),
					resourceId : 'ambient_temperature',
					value : {
						ambient_temperature : ambientTemp.toFixed(1)
					}
				}, ambientTemp.toFixed(1));

				cb();
			})
		}, function(cb) {
			if(!handypia.hasContainSensor('accelerometer')) {
				cb();
				return;
			}

			connectedSensorTag.readAccelerometer(function(err, x, y, z) {
				if (err) {
					console.log('> Read accelerometer error: ', err);
					cb();
					return;
				}

				handypia.sendReport('accelerometer', {
					thingId : config.sensorTag.AE.origin,
					time : dateFormat(new Date(), 'yyyymmddHHMMss'),
					resourceId : 'accelerometer',
					value : {
						x : x.toFixed(1),
						y : y.toFixed(1),
						z : z.toFixed(1)
					}
				}, 'x: ' + x + ' - y: ' + y + ' - z: ' + z);

				cb();
			})
		}, function(cb) {
			if(!handypia.hasContainSensor('humidity')) {
				cb();
				return;
			}

			connectedSensorTag.readHumidity(function(err, temperature, humidity) {
				if (err) {
					console.log('> Read humidity error: ', err);
					cb();
					return;
				}

				handypia.sendReport('temperature', {
					thingId : config.sensorTag.AE.origin,
					time : dateFormat(new Date(), 'yyyymmddHHMMss'),
					resourceId : 'temperature',
					value : {
						temperature : temperature.toFixed(1)
					}
				}, temperature.toFixed(1));

				handypia.sendReport('humidity', {
					thingId : config.sensorTag.AE.origin,
					time : dateFormat(new Date(), 'yyyymmddHHMMss'),
					resourceId : 'humidity',
					value : {
						humidity : humidity.toFixed(1)
					}
				}, humidity.toFixed(1));

				cb();
			})
		}, function(cb) {
			if(!handypia.hasContainSensor('magnetometer')) {
				cb();
				return;
			}

			connectedSensorTag.readMagnetometer(function(err, x, y, z) {
				if (err) {
					console.log('> Read magnetometer error: ', err);
					cb();
					return;
				}

				handypia.sendReport('magnetometer', {
					thingId : config.sensorTag.AE.origin,
					time : dateFormat(new Date(), 'yyyymmddHHMMss'),
					resourceId : 'magnetometer',
					value : {
						x : x.toFixed(1),
						y : y.toFixed(1),
						z : z.toFixed(1)
					}
				}, 'x: ' + x + ' - y: ' + y + ' - z: ' + z);

				cb();
			})
		}, function(cb) {
			if(!handypia.hasContainSensor('barometric')) {
				cb();
				return;
			}

			connectedSensorTag.readBarometricPressure(function(err, pressure) {
				if (err) {
					console.log('> Read barometric pressure error: ', err);
					cb();
					return;
				}

				handypia.sendReport('barometric', {
					thingId : config.sensorTag.AE.origin,
					time : dateFormat(new Date(), 'yyyymmddHHMMss'),
					resourceId : 'barometric',
					value : {
						barometric : pressure.toFixed(1)
					}
				}, pressure.toFixed(1));

				cb();
			})
		}, function(cb) {
			if(!handypia.hasContainSensor('gyroscope')) {
				cb();
				return;
			}

			connectedSensorTag.readGyroscope(function(err, x, y, z) {
				if (err) {
					console.log('> Read gyroscope error: ', err);
					cb();
					return;
				}

				handypia.sendReport('gyroscope', {
					thingId : config.sensorTag.AE.origin,
					time : dateFormat(new Date(), 'yyyymmddHHMMss'),
					resourceId : 'gyroscope',
					value : {
						x : x.toFixed(1),
						y : y.toFixed(1),
						z : z.toFixed(1)
					}
				}, 'x: ' + x + ' - y: ' + y + ' - z: ' + z);

				cb();
			})
		}, function(cb) {
			if(!handypia.hasContainSensor('luxometer')) {
				cb();
				return;
			}

			connectedSensorTag.readLuxometer(function(err, lux) {
				if (err) {
					console.log('> Read luxometer error: ', err);
					cb();
					return;
				}

				handypia.sendReport('luxometer', {
					thingId : config.sensorTag.AE.origin,
					time : dateFormat(new Date(), 'yyyymmddHHMMss'),
					resourceId : 'luxometer',
					value : {
						luxometer : lux.toFixed(1)
					}
				}, lux.toFixed(1));

				cb();
			})
		}
	], function(err) {
		isReporting = false;
		if (err) {
			console.error('> ERROR: ', err);
			sensorTag.disconnect();
		}
	});
}

exports.setup = function() {
	// run discover device and registration device
	crontab.scheduleJob(config.sensorTag.crontab.connectRetry, function() {
		getConnnectDevice();
	});
}

exports.report = function() {
	// run sensing value report
	crontab.scheduleJob(config.sensorTag.crontab.sensingReport, function() {
		sensingReport();
	});
}