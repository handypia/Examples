var async = require('async');
var fs = require('fs');
var dateFormat = require('dateformat');
var util = require('util');

exports.getRequestQuery = function(req, res) {
	var query = req.query;

	if (Object.keys(req.body).length > 0) {
		for ( var key in req.body) {
			query[key] = req.body[key];
		}
	}

	if (Object.keys(req.params).length > 0) {
		for ( var key in req.params) {
			query[key] = req.params[key];
		}
	}

	return query;
};

exports.stringToArray = function(str) {
	var array = new Array();
	var dummy = str.split(",");

	for ( var i in dummy) {
		array.push(dummy[i].trim());
	}

	return array;
}

exports.generateId = function() {
	return puid.generate();
}

exports.currentTime = function() {
	var now = new Date();
	var jsonDate = now.toJSON();
	return new Date(jsonDate);
}

exports.getTimedFolderPath = function(prefix) {
	var now = new Date();

	if (prefix)
		return prefix + '/' + dateFormat(now, 'yyyy/mm/dd/hh/MM');
	else
		return dateFormat(now, 'yyyy/mm/dd/hh/MM');
}

exports.deleteDummyContentFile = function(path) {
	fs.unlink(path, function(err) {
		if (err) {
			console.error('==>> ERROR', err);
			return;
		}
	});
}

exports.isEmpty = function (value) {
	return typeof value == 'string' && !value.trim() || typeof value === 'undefined' || value === null || value === 'undefined';
}