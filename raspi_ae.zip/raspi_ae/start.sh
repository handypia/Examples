#!/bin/bash

if [! -d ${PWD##}/logs]
then
	mkdir -p ${PWD##}/logs
fi

forever start -a -l ${PWD##}/logs/node.out bin/www